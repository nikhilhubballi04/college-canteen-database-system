
# College-Canteen-Management-System
This is a web based canteen management system application project

1. Navigate to XAMPP in your system or simply launch it by clicking the XAMPP Creating MySQL Database with XAMPP Icon. The Control Panel is now visible and can be used to initiate or halt the working of any module.

2. Place the extracted zip file in c:/xampp/htdocs directory

3. Click on the "Start" button corresponding to Apache and MySQL modules.

4. Now click on the "Admin" button corresponding to the MySQL module. This automatically redirects the user to a web browser to the following address-
http://localhost/phpmyadmin

5. Create a database in the name "sahyadri_canteen"

6. Click on the import tab in phpmyadmin and import the sql file from c:/xampp/htdocs directory

7. Once the sql file is imported, open a new tab in the same web browser to call the url "http://localhost/Sahyadri_Canteen_Main/". for admin page use the url- "http://localhost/Sahyadri_Canteen_Main/admin/"

   ![er diagram](https://github.com/sanjana459/College-Canteen-Management-System/assets/85347345/ea735dfa-0543-4bfc-b3c0-0034277316ab)

   ![home page](https://github.com/sanjana459/College-Canteen-Management-System/assets/85347345/2cd53a3c-e048-4df8-9983-bb6922efe202)

  ![admin dashboard](https://github.com/sanjana459/College-Canteen-Management-System/assets/85347345/5c4a03ca-2327-482c-a2e2-e3170690741c)



